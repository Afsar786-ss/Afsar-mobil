AFSAR MOBILE — COVER CHECKER (Android project)

Is folder mein app ka Android Studio source project hai. Yeh APK file nahi hai.

APK banane ka tareeka:
1. Computer par Android Studio install karo.
2. Android Studio mein "Open" select karke is folder ko kholo.
3. Gradle sync complete hone do.
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Build complete hone par "locate" par click karke app-debug.apk pao.
6. APK ko apne Android phone mein bhejo, tap karke install karo. Zarurat pade toh Android ki install permission allow karo.

App ke features:
- Model search
- HAI / NAHI status
- Model add/edit
- Category, quantity, box/rack
- JSON backup and restore
- Stock list isi app ke local WebView storage mein save hoti hai

IMPORTANT:
- App ko uninstall ya app storage clear karne se local list delete ho sakti hai. Regular Backup Download zaroor karo.
- Pehli baar app kholne par apna actual stock khud add karo. Demo models sirf examples hain.
